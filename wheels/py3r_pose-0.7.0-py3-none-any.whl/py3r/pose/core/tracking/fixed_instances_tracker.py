from typing import List, Union

import numpy as np
from scipy.optimize import linear_sum_assignment

from py3r.pose.core.types.instance_type import PoseInstanceType
from py3r.pose.core.types.instance import PoseInstance


class Track:
    def __init__(self, track_id: str):
        self.track_id = track_id
        self.start_frame = None
        self.last_pose = None

    def update(self, pose: PoseInstance):
        self.last_pose = pose


MISSING_POINT_PENALTY = 0.1


def pose_distance(pose1: PoseInstance, pose2: PoseInstance) -> float:
    instance_1_diag = ((pose1.box[2] - pose1.box[0]) ** 2 + (pose1.box[3] - pose1.box[1]) ** 2) ** 0.5
    instance_2_diag = ((pose2.box[2] - pose2.box[0]) ** 2 + (pose2.box[3] - pose2.box[1]) ** 2) ** 0.5
    scale = (instance_1_diag + instance_2_diag) / 2

    dist = 0
    missing_point_penalty = 0
    for p1, p2 in zip(pose1.points, pose2.points):
        if p1 is None and p2 is None:
            continue
        if p1 is None or p2 is None:
            missing_point_penalty += MISSING_POINT_PENALTY
            continue
        point_dist = (((p1.x - p2.x) ** 2 + (p1.y - p2.y) ** 2) ** 2) / scale
        dist += point_dist
    dist += missing_point_penalty
    return dist / len(pose1.points)


pose_dists = []
time_dists = []


class FixedInstancesTracker:
    """
    This tracker can be used when you know exactly how many instances of each type there are in the video.
    It has the advantage that it smartly filters out false positives by discarding instances
    that did not appear in the previous frame.
    """
    def __init__(self, instances: List[Union[PoseInstanceType, str]]):
        self.instance_types = [instance_type.name if isinstance(instance_type, PoseInstanceType) else instance_type for instance_type in instances]

        self.num_instances_per_type = {}
        for instance_type in self.instance_types:
            if instance_type not in self.num_instances_per_type:
                self.num_instances_per_type[instance_type] = 0
            self.num_instances_per_type[instance_type] += 1

        self.tracks = {}
        for instance_type in self.instance_types:
            if instance_type not in self.tracks:
                self.tracks[instance_type] = []
            track_id = instance_type + f"_{len(self.tracks[instance_type])}"
            self.tracks[instance_type].append(Track(track_id))

    def filter(self, pose_results: List[PoseInstance]) -> List[PoseInstance]:
        instances = [instance for instance in pose_results if any([point is not None for point in instance.points])]
        tracked_instances = []

        for instance_type_name, num_instances in self.num_instances_per_type.items():
            instance_type_tracks = self.tracks[instance_type_name]
            instance_type_instances = [instance for instance in instances if instance.type.name == instance_type_name]

            if len(instance_type_tracks) == len(instance_type_instances) == 1:
                instance_type_tracks[0].update(instance_type_instances[0])
                instance_type_instances[0].id = instance_type_tracks[0].track_id
                tracked_instances.append(instance_type_instances[0])
                continue

            n_tracks = len(instance_type_tracks)
            n_instances = len(instance_type_instances)

            cost_matrix = np.zeros((n_tracks, n_instances))
            for i, track in enumerate(instance_type_tracks):
                for j, instance in enumerate(instance_type_instances):
                    if track.last_pose is None:
                        cost_matrix[i, j] = 0.
                    else:
                        cost_matrix[i, j] = pose_distance(track.last_pose, instance)

            row_ind, col_ind = linear_sum_assignment(cost_matrix)

            for i, j in zip(row_ind, col_ind):
                track = instance_type_tracks[i]
                instance = instance_type_instances[j]
                track.update(instance)
                instance.id = track.track_id
                tracked_instances.append(instance)
        return tracked_instances

    def filter_all(self, pose_results_list: List[List[PoseInstance]]) -> List[List[PoseInstance]]:
        return [self.filter(instances) for instances in pose_results_list]
